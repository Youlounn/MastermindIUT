<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
require_once "controleur/base.php";

$base=new base();

$base->lancement();

?>
